# Sample Coding Questions 01 Week 01
# Gadise Oli
# Define an array variable with the elements 1, 4, 7, 9
array_variable = [1, 4, 7, 9]
# Define 4 variables a, b, c, d
a = 1
b = 2
c = 3
d = 4

# Fully bracketed version of e = a * c - b / d
e = (a * c) - (b / d)

# Given line of code: e = a - b ** c // d + a % c
# Fully bracketed version:
e = (a - ((b ** c) // d)) + (a % c)
# formatting
temperature = 32.6
print("The temperature today is: {:.3f} degrees Celsius".format(temperature))
# common functions
userAge = int(input("Enter your age: "))
userAge += 22
print("Now showing the shop items filtered by age: {}".format(userAge))
